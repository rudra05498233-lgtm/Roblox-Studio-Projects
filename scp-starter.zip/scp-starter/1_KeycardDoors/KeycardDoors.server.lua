--!strict
-- PUT IN: ServerScriptService (Script)
-- Doors: any Part tagged "KeycardDoor" (Tag Editor) with attribute RequiredLevel (number).
-- Keycards: Tools with attribute KeycardLevel (number).

local CollectionService = game:GetService("CollectionService")
local TweenService = game:GetService("TweenService")

local MAX_DISTANCE = 14 -- server-side distance check (anti-exploit)
local STAY_OPEN_TIME = 3
local COOLDOWN = 1

local KeycardDoor = {}
KeycardDoor.__index = KeycardDoor

function KeycardDoor.new(part: BasePart)
	local self = setmetatable({}, KeycardDoor)
	self.part = part
	self.level = part:GetAttribute("RequiredLevel") or 1
	self.busy = false
	self.closedCFrame = part.CFrame
	self.openCFrame = part.CFrame * CFrame.new(0, part.Size.Y, 0) -- slides up
	self.tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quad)

	part.Anchored = true

	local prompt = part:FindFirstChildOfClass("ProximityPrompt")
	if not prompt then
		prompt = Instance.new("ProximityPrompt")
		prompt.ActionText = "Swipe card"
		prompt.ObjectText = "Level " .. self.level .. " door"
		prompt.MaxActivationDistance = 8
		prompt.Parent = part
	end
	prompt.Triggered:Connect(function(player)
		self:tryOpen(player)
	end)
	return self
end

local function getClearance(player: Player): number
	local best = 0
	local containers = { player.Backpack, player.Character }
	for _, container in containers do
		if container then
			for _, item in container:GetChildren() do
				if item:IsA("Tool") then
					local level = item:GetAttribute("KeycardLevel")
					if type(level) == "number" and level > best then
						best = level
					end
				end
			end
		end
	end
	return best
end

function KeycardDoor:tryOpen(player: Player)
	if self.busy then return end

	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if not root then return end
	if (root.Position - self.part.Position).Magnitude > MAX_DISTANCE then return end

	if getClearance(player) < self.level then
		-- denied: play a sound / fire a client UI message here
		return
	end

	self.busy = true
	TweenService:Create(self.part, self.tweenInfo, { CFrame = self.openCFrame }):Play()
	task.wait(STAY_OPEN_TIME)
	TweenService:Create(self.part, self.tweenInfo, { CFrame = self.closedCFrame }):Play()
	task.wait(COOLDOWN)
	self.busy = false
end

for _, part in CollectionService:GetTagged("KeycardDoor") do
	KeycardDoor.new(part)
end
CollectionService:GetInstanceAddedSignal("KeycardDoor"):Connect(function(part)
	KeycardDoor.new(part)
end)
