--!strict
-- PUT IN: ServerScriptService (Script)
-- Needs: a rig Model in Workspace named "SCP173" (Humanoid + HumanoidRootPart, unanchored).
-- Behavior: moves toward the nearest player ONLY when nobody is looking at it. Kills on contact.

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local SPEED = 45
local KILL_DISTANCE = 5
local VIEW_DOT = 0.3 -- ~72 degree cone in front of a player's head
local MAX_SEE_RANGE = 200

local SCP173 = {}
SCP173.__index = SCP173

function SCP173.new(model: Model)
	local self = setmetatable({}, SCP173)
	self.model = model
	self.humanoid = model:WaitForChild("Humanoid") :: Humanoid
	self.root = model:WaitForChild("HumanoidRootPart") :: BasePart
	self.humanoid.WalkSpeed = SPEED
	self.root:SetNetworkOwner(nil) -- server controls it, no physics exploits
	return self
end

-- Is this character looking at the statue with a clear line of sight?
function SCP173:isSeenBy(character: Model): boolean
	local head = character:FindFirstChild("Head") :: BasePart?
	if not head then return false end

	local toStatue = self.root.Position - head.Position
	if toStatue.Magnitude > MAX_SEE_RANGE then return false end
	if head.CFrame.LookVector:Dot(toStatue.Unit) < VIEW_DOT then return false end

	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { self.model, character }
	return workspace:Raycast(head.Position, toStatue, params) == nil
end

function SCP173:update()
	local nearest: Model? = nil
	local nearestDist = math.huge

	for _, player in Players:GetPlayers() do
		local character = player.Character
		local hum = character and character:FindFirstChildOfClass("Humanoid")
		local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
		if character and hum and root and hum.Health > 0 then
			if self:isSeenBy(character) then
				self.humanoid:MoveTo(self.root.Position) -- frozen
				return
			end
			local dist = (root.Position - self.root.Position).Magnitude
			if dist < nearestDist then
				nearest, nearestDist = character, dist
			end
		end
	end

	if nearest then
		local targetRoot = nearest:FindFirstChild("HumanoidRootPart") :: BasePart
		if nearestDist <= KILL_DISTANCE then
			local hum = nearest:FindFirstChildOfClass("Humanoid")
			if hum then hum.Health = 0 end -- neck snap: add sound/animation here
		else
			self.humanoid:MoveTo(targetRoot.Position)
		end
	end
end

local model = workspace:WaitForChild("SCP173") :: Model
local scp = SCP173.new(model)

local accumulator = 0
RunService.Heartbeat:Connect(function(dt)
	accumulator += dt
	if accumulator >= 0.1 then -- 10 checks/second is enough
		accumulator = 0
		scp:update()
	end
end)
