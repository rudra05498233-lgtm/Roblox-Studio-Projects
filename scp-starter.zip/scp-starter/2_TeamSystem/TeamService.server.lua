--!strict
-- PUT IN: ServerScriptService (Script)

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local rankStore = DataStoreService:GetDataStore("PlayerRanks_v1")

-- Add/edit teams here. MinRank = rank needed to join.
local TEAM_CONFIG = {
	{ Name = "Class-D", Color = BrickColor.new("Bright orange"), MinRank = 0 },
	{ Name = "Scientist", Color = BrickColor.new("White"), MinRank = 0 },
	{ Name = "Guard", Color = BrickColor.new("Navy blue"), MinRank = 1 },
	{ Name = "Security Chief", Color = BrickColor.new("Really black"), MinRank = 3 },
}

local RANK_UP_EVERY = 600 -- seconds played per rank (demo progression)
local MAX_RANK = 3

local chooseTeam = Instance.new("RemoteEvent")
chooseTeam.Name = "ChooseTeam"
chooseTeam.Parent = ReplicatedStorage

local getTeams = Instance.new("RemoteFunction")
getTeams.Name = "GetTeams"
getTeams.Parent = ReplicatedStorage

for _, info in TEAM_CONFIG do
	local team = Instance.new("Team")
	team.Name = info.Name
	team.TeamColor = info.Color
	team.AutoAssignable = false
	team.Parent = Teams
end

local ranks: { [number]: number } = {}

local function loadRank(player: Player)
	local ok, value = pcall(function()
		return rankStore:GetAsync(tostring(player.UserId))
	end)
	ranks[player.UserId] = (ok and type(value) == "number") and value or 0
end

local function saveRank(player: Player)
	local rank = ranks[player.UserId]
	if rank == nil then return end
	local ok, err = pcall(function()
		rankStore:SetAsync(tostring(player.UserId), rank)
	end)
	if not ok then
		warn("Failed to save rank for", player.Name, err)
	end
end

Players.PlayerAdded:Connect(function(player)
	loadRank(player)

	task.spawn(function() -- demo: earn rank by playing
		while player.Parent do
			task.wait(RANK_UP_EVERY)
			local current = ranks[player.UserId]
			if player.Parent and current and current < MAX_RANK then
				ranks[player.UserId] = current + 1
			end
		end
	end)
end)

Players.PlayerRemoving:Connect(function(player)
	saveRank(player)
	ranks[player.UserId] = nil
end)

game:BindToClose(function()
	for _, player in Players:GetPlayers() do
		saveRank(player)
	end
end)

getTeams.OnServerInvoke = function(player)
	return TEAM_CONFIG, ranks[player.UserId] or 0
end

chooseTeam.OnServerEvent:Connect(function(player, teamName)
	-- never trust the client: validate everything
	if type(teamName) ~= "string" then return end

	local info
	for _, t in TEAM_CONFIG do
		if t.Name == teamName then
			info = t
			break
		end
	end
	if not info then return end
	if (ranks[player.UserId] or 0) < info.MinRank then return end

	local team = Teams:FindFirstChild(teamName)
	if team and player.Team ~= team then
		player.Team = team :: Team
		player:LoadCharacter()
	end
end)
