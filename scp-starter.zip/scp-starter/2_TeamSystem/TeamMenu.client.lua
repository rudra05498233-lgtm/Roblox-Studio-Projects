--!strict
-- PUT IN: StarterPlayer > StarterPlayerScripts (LocalScript)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local chooseTeam = ReplicatedStorage:WaitForChild("ChooseTeam") :: RemoteEvent
local getTeams = ReplicatedStorage:WaitForChild("GetTeams") :: RemoteFunction

local gui = Instance.new("ScreenGui")
gui.Name = "TeamMenu"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(300, 320)
frame.Position = UDim2.fromScale(0.5, 0.5)
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
frame.Parent = gui
Instance.new("UICorner", frame)

local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 8)
layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
layout.Parent = frame

local pad = Instance.new("UIPadding")
pad.PaddingTop = UDim.new(0, 12)
pad.Parent = frame

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -20, 0, 30)
title.BackgroundTransparency = 1
title.TextColor3 = Color3.new(1, 1, 1)
title.Font = Enum.Font.GothamBold
title.TextSize = 20
title.Text = "Choose your team"
title.Parent = frame

local teams, rank = getTeams:InvokeServer()

for _, info in teams do
	local locked = rank < info.MinRank
	local button = Instance.new("TextButton")
	button.Size = UDim2.new(1, -24, 0, 50)
	button.BackgroundColor3 = info.Color.Color
	button.AutoButtonColor = not locked
	button.Font = Enum.Font.GothamMedium
	button.TextSize = 18
	button.TextColor3 = (info.Name == "Scientist") and Color3.new(0, 0, 0) or Color3.new(1, 1, 1)
	button.Text = locked and (info.Name .. "  (Rank " .. info.MinRank .. ")") or info.Name
	button.BackgroundTransparency = locked and 0.6 or 0
	button.Parent = frame
	Instance.new("UICorner", button)

	button.Activated:Connect(function()
		if locked then return end
		chooseTeam:FireServer(info.Name)
		gui.Enabled = false
	end)
end
