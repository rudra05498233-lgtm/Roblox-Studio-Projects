# SCP Starter Projects (Luau)

Copy each script into Roblox Studio and playtest.

## 1. Keycard Doors
- Script -> ServerScriptService: 1_KeycardDoors/KeycardDoors.server.lua
- Make a Part as a door. Tag it KeycardDoor (View > Tag Editor). Add attribute RequiredLevel (number, e.g. 2).
- Make a Tool, add attribute KeycardLevel (number). Put a copy in StarterPack to test.
- Use the prompt at the door. Level too low = nothing happens.

## 2. Team System
- Script -> ServerScriptService: TeamService.server.lua
- LocalScript -> StarterPlayerScripts: TeamMenu.client.lua
- Enable "Enable Studio Access to API Services" (Game Settings > Security) to test DataStores.
- Edit TEAM_CONFIG for teams and rank requirements.

## 3. SCP-173 style entity
- Put a rig Model named SCP173 in Workspace (Humanoid + HumanoidRootPart, not anchored).
- Script -> ServerScriptService: SCP173.server.lua
- Looked at = frozen. Looked away = chases. Close range = kills.

## Upgrades to make them portfolio-worthy
- Doors: deny sound + UI message, double doors, remote open from a control room.
- Teams: spawn points per team, team slot limits, admin promote command.
- SCP: PathfindingService, blink meter, sounds, validated client camera direction for "seen" checks.

## Portfolio checklist
- Record a 30-60s video of each.
- Put code on GitHub with this README.
- Add a one-line note on what you learned in each.
